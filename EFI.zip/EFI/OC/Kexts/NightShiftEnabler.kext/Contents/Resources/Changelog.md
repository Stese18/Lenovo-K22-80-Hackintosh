NightShiftEnabler Changelog
===========================
#### v1.1.1
- Fix Monterey compatibility

#### v1.1.0
- Rewrite to use basic Lilu userspace patching APIs for Big Sur compatibility

#### v1.0.0
- Initial release
